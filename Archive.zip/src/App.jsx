import { useEffect, useState } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";
import Notifications from "./pages/Notifications";

import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Sermons from "./pages/Sermons";
import SundaySchool from "./pages/SundaySchool";
import Homilys from "./pages/Homilys";
import About from "./pages/About";
import Feedback from "./pages/Feedback";
import Settings from "./pages/Settings";
import SignUp from "./pages/SignUp";

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Listen for login state
  useEffect(() => {
  const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
    if (currentUser) {
      const lastActivity = localStorage.getItem("lastActivity");
      const now = Date.now();
      const threeDays = 3 * 24 * 60 * 60 * 1000;

      if (lastActivity && now - parseInt(lastActivity) > threeDays) {
        await signOut(auth);
        localStorage.removeItem("lastActivity");
        setUser(null);
      } else {
        setUser(currentUser);
      }
    } else {
      setUser(null);
    }

    setLoading(false);
  });

  return () => unsubscribe();
}, []);
useEffect(() => {
  const updateActivity = () => {
    localStorage.setItem("lastActivity", Date.now().toString());
  };

  window.addEventListener("click", updateActivity);
  window.addEventListener("keydown", updateActivity);
  window.addEventListener("mousemove", updateActivity);

  return () => {
    window.removeEventListener("click", updateActivity);
    window.removeEventListener("keydown", updateActivity);
    window.removeEventListener("mousemove", updateActivity);
  };
}, []);


  if (loading) {
    return null; // or you can return a loading spinner
  }

  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/sermons" element={<Sermons />} />
        <Route path="/sundayschool" element={<SundaySchool />} />
        <Route path="/homilys" element={<Homilys />} />
        <Route path="/about" element={<About />} />
        <Route path="/feedback" element={<Feedback />} />
        <Route path="/signup" element={<SignUp />} />
<Route path="/notifications" element={<Notifications />} />

        {/* 🔒 Protected Settings Route */}
        <Route
  path="/account"
  element={user ? <Settings /> : <Navigate to="/" />}
/>


      </Routes>
    </>
  );
}

export default App;
