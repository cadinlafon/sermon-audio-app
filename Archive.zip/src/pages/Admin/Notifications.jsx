export default function Notifications() {
  return <h2>Notifications Page Works</h2>;
}
