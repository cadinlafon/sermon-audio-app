export default function Analytics() {
  return <h2>Analytics Page Works</h2>;
}
