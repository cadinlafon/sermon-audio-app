export default function Users() {
  return <h2>Users Page Works</h2>;
}
