import { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, getDocs } from "firebase/firestore";

export default function Sermons() {
  const [sermons, setSermons] = useState([]);

  useEffect(() => {
    async function fetchSermons() {
  try {
    const querySnapshot = await getDocs(collection(db, "audio"));
    console.log("Docs found:", querySnapshot.docs.length);

    const sermonList = querySnapshot.docs.map((doc) => {
      console.log("Doc data:", doc.data());
      return {
        id: doc.id,
        ...doc.data(),
      };
    });

    setSermons(sermonList);
  } catch (error) {
    console.error("Error fetching sermons:", error);
  }
}


    fetchSermons();
  }, []);

  return (
    <div style={{ padding: "40px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "40px" }}>
        Sermons
      </h1>

      {sermons.length === 0 ? (
        <p>No sermons found.</p>
      ) : (
        sermons.map((sermon) => (
          <div
            key={sermon.id}
            style={{
              background: "#ffffff",
              padding: "20px",
              marginBottom: "25px",
              borderRadius: "12px",
              boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
              maxWidth: "600px",
              margin: "0 auto 25px auto",
            }}
          >
            <h3 style={{ marginBottom: "5px" }}>{sermon.title}</h3>

            <p style={{ fontWeight: "bold", color: "#555" }}>
              Pastor: {sermon.pastor}
            </p>

            <p style={{ marginBottom: "15px" }}>
              {sermon.description}
            </p>

            {sermon.audioUrl && (
              <audio controls style={{ width: "100%" }}>
                <source src={sermon.audioUrl} type="audio/mpeg" />
                Your browser does not support the audio element.
              </audio>
            )}
          </div>
        ))
      )}
    </div>
  );
}
