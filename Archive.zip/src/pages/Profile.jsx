export default function Profile() {
  return (
    <div style={{ padding: "40px" }}>
      Profile Page Working
    </div>
  );
}
