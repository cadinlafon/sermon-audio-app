import { useRef, useState } from "react";

function AudioPlayerBar() {
  const audioRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);

  // Temporary test audio (replace later with sermons)
  const audioSrc =
    "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";

  const togglePlay = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }

    setIsPlaying(!isPlaying);
  };

  const rewind10 = () => {
    if (!audioRef.current) return;
    audioRef.current.currentTime -= 10;
  };

  return (
    <>
      <audio ref={audioRef} src={audioSrc} />

      <div className="audio-bar">
        <div className="audio-info">
          <p className="audio-title">Sample Sermon</p>
        </div>

        <div className="audio-controls">
          <button onClick={rewind10}>⏪ 10</button>
          <button onClick={togglePlay}>
            {isPlaying ? "⏸" : "▶️"}
          </button>
        </div>
      </div>
    </>
  );
}

export default AudioPlayerBar;
