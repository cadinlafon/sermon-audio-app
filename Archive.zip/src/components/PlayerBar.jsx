function PlayerBar() {
  return (
    <div className="player">
      <span>Latest Sermon</span>
      <button>⏪ 10s</button>
      <button>▶️</button>
    </div>
  );
}

export default PlayerBar;
