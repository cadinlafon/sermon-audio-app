const sermons = [
  {
    id: 1,
    title: "Faith Over Fear",
    speaker: "Pastor John",
    date: "2026-02-01",
    audioUrl: "/audio/faith.mp3"
  },
  {
    id: 2,
    title: "Walking in Purpose",
    speaker: "Pastor John",
    date: "2026-02-08",
    audioUrl: "/audio/purpose.mp3"
  }
]

export default sermons
